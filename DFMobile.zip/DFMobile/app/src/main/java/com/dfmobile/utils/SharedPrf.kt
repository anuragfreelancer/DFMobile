package com.dfmobile.utils

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.dfmobile.R


class SharedPrf constructor(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(context.getString(R.string.app_name), Context.MODE_PRIVATE)
    private val USER = "DFMobile"
    fun getStoredTag(str: String): String {
        return prefs.getString(str, "")!!
    }

    fun setStoredTag(str: String, query: String) {
        prefs.edit().putString(str, query).apply()
    }



    fun clearAll() {
        prefs.edit().clear().apply()
    }

    companion object {


        private var INSTANCE: SharedPrf? = null

        // This is the method that returns the singleton instance
        @JvmStatic
        fun getInstance(context: Context): SharedPrf {
            // Using synchronized block for thread-safety
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SharedPrf(context.applicationContext).also { INSTANCE = it }
            }
        }



        const val LOGIN: String = "login"
        const val USER_ID: String = "user_id"
        const val USER_NAME: String = "user_name"

        const val DYNAMIC_BASE_URL: String = "base_url"



    }

}
