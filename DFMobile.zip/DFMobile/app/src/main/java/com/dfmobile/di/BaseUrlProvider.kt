package com.dfmobile.di

import com.dfmobile.utils.SharedPrf
import javax.inject.Inject

class BaseUrlProvider @Inject constructor(private val sharedPrf: SharedPrf) {

    fun getBaseUrl(): String {
        // Access shared preferences via SharedPrf
        val baseUrl = sharedPrf.getStoredTag(SharedPrf.DYNAMIC_BASE_URL) ?: "https://local.df-server.info:24003/mmobile_3/"
        return if (baseUrl.endsWith("/")) {
            baseUrl
        } else {
            "$baseUrl/"
        }
    }
}
