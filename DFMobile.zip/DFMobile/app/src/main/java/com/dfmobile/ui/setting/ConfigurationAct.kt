package com.dfmobile.ui.setting

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.dfmobile.R
import com.dfmobile.databinding.ActivityUserSettingBinding
import com.dfmobile.ui.connection.SplashAct
import com.dfmobile.utils.Helper
import com.dfmobile.utils.NetworkResult
import com.dfmobile.utils.SharedPrf
import com.dfmobile.viewmodel.ConfigurationViewModel
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject

@AndroidEntryPoint
class ConfigurationAct : AppCompatActivity() {
    private lateinit var binding : ActivityUserSettingBinding
    private lateinit var configurationViewModel: ConfigurationViewModel

    private val sharedPrf by lazy { SharedPrf(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_user_setting)
        configurationViewModel = ViewModelProvider(this)[ConfigurationViewModel::class.java]

        initViews()
    }

    private fun initViews() {

        binding.tvUser.text = getString(R.string.users)+sharedPrf.getStoredTag(SharedPrf.USER_NAME)

        binding.tvServer.text = getString(R.string.server)+sharedPrf.getStoredTag(SharedPrf.DYNAMIC_BASE_URL)


        binding.btnLogout.setOnClickListener {
            logoutDialog()
        }

        bindObservers()

        configurationViewModel.userConfiguration(sharedPrf.getStoredTag(SharedPrf.USER_ID),this@ConfigurationAct)


    }


    private fun bindObservers() {
        configurationViewModel.configurationLiveData.observe(this) {it->
            Helper.hideProgressMessage()
            when (it) {
                is NetworkResult.Success -> {
                    it.data?.let {
                        val jsonObject = JSONObject(it.string())
                        Log.e("user configuration Response===",jsonObject.toString())
                        if (jsonObject.getInt("ErrorCode")==0) {

                            if(jsonObject.getJSONObject("Response").getBoolean("PedirNombre"))
                                binding.tvRequestName.text = getString(R.string.yes_ask_me)
                             else  binding.tvRequestName.text = getString(R.string.not_ask_me)



                            if(jsonObject.getJSONObject("Response").getInt("RellenarIndices")==1)
                                binding.tvIndices.text = getString(R.string.yes_fill_in_indices)
                            else  binding.tvRequestName.text = getString(R.string.do_not_fill_in_indices)

                            binding.tvPattern.text =jsonObject.getJSONObject("Response").getString("PatronNombre")



                        } else {
                            Toast.makeText(
                                this@ConfigurationAct,
                                "" + jsonObject.getString("message"),
                                Toast.LENGTH_SHORT
                            ).show()




                        }

                    }




                }

                is NetworkResult.Error -> {
                       Toast.makeText(
                           this@ConfigurationAct,
                           "" + it.message.toString(),
                           Toast.LENGTH_SHORT
                       ).show()

                }

                is NetworkResult.Loading -> {
                    Helper.showProgressMessage(this@ConfigurationAct,getString(R.string.please_wait))
                }

                else -> {}
            }
        }


        configurationViewModel.logoutLiveData.observe(this) {it->
            Helper.hideProgressMessage()
            when (it) {
                is NetworkResult.Success -> {
                    it.data?.let {
                        val jsonObject = JSONObject(it.string())
                        Log.e("user logout Response===",jsonObject.toString())
                        if (jsonObject.getInt("ErrorCode")==0) {
                            sharedPrf.clearAll()
                            startActivity(Intent(this@ConfigurationAct, SplashAct::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                            finish()
                        } else {
                            Toast.makeText(
                                this@ConfigurationAct,
                                "" + jsonObject.getString("message"),
                                Toast.LENGTH_SHORT
                            ).show()

                        }

                    }


                }

                is NetworkResult.Error -> {
                    Toast.makeText(
                        this@ConfigurationAct,
                        "" + it.message.toString(),
                        Toast.LENGTH_SHORT
                    ).show()

                }

                is NetworkResult.Loading -> {
                    Helper.showProgressMessage(this@ConfigurationAct,getString(R.string.please_wait))
                }

                else -> {}
            }
        }


    }


    private fun logoutDialog() {
        val dialogView =
            LayoutInflater.from(this@ConfigurationAct).inflate(R.layout.dialog_logout, null)
        val dialogBuilder = AlertDialog.Builder(this@ConfigurationAct).setView(dialogView)

        val alertDialog = dialogBuilder.create()

        // Apply custom rounded corner background
        alertDialog.window?.setBackgroundDrawableResource(R.drawable.dialog_rounded_bg)

        // Set listeners or actions if needed
        val btnCancel: Button = dialogView.findViewById(R.id.btnCancel)

        val btnClose: Button = dialogView.findViewById(R.id.btnClose)


        btnCancel.setOnClickListener {
            alertDialog.dismiss()
        }

        btnClose.setOnClickListener {
            alertDialog.dismiss()
            configurationViewModel.userLogout(this@ConfigurationAct)

        }


        // Show the dialog
        alertDialog.show()
    }




}