package com.dfmobile.ui.login

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.dfmobile.R
import com.dfmobile.databinding.ActivityLoginBinding
import com.dfmobile.ui.connection.SelectServerTypeAct
import com.dfmobile.ui.connection.SplashAct
import com.dfmobile.ui.home.HomeAct
import com.dfmobile.utils.Helper
import com.dfmobile.utils.NetworkResult
import com.dfmobile.utils.SharedPrf
import com.dfmobile.viewmodel.LoginViewModel
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject

@AndroidEntryPoint
class LoginAct : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var loginViewModel: LoginViewModel
    private val sharedPrf by lazy { SharedPrf(this) }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_login)
        loginViewModel = ViewModelProvider(this)[LoginViewModel::class.java]

        initViews()
    }

    private fun initViews() {

        binding.ivBack.setOnClickListener {
            finish()
        }

        binding.btnForgetServer.setOnClickListener {
            forgetServerDialog()
        }

        binding.ivRefresh.setOnClickListener {
            binding.tvError.text = ""
            binding.tvError.visibility = View.GONE
            binding.edUser.background = getDrawable(R.drawable.rounded_white_border10)
            binding.edKeyPin.background = getDrawable(R.drawable.rounded_white_border10)
        }

        binding.btnLogin.setOnClickListener {
            binding.tvError.text = ""
            binding.tvError.visibility = View.GONE

            if (binding.edUser.text.toString() == "" && binding.edKeyPin.text.toString() == "") {
                binding.tvError.visibility = View.VISIBLE
                binding.tvError.text = getString(R.string.all_field_are_mandatory)
                binding.edUser.background = getDrawable(R.drawable.rounded_red_border10)
                binding.edKeyPin.background = getDrawable(R.drawable.rounded_red_border10)
            } else if (binding.edUser.text.toString() == "") {
                binding.tvError.visibility = View.VISIBLE
                binding.tvError.text = getString(R.string.enter_user_name)
                binding.edUser.background = getDrawable(R.drawable.rounded_red_border10)
                binding.edKeyPin.background = getDrawable(R.drawable.rounded_white_border10)

            } else if (binding.edKeyPin.text.toString() == "") {
                binding.tvError.visibility = View.VISIBLE
                binding.tvError.text = getString(R.string.enter_pin_or_key)
                binding.edUser.background = getDrawable(R.drawable.rounded_white_border10)
                binding.edKeyPin.background = getDrawable(R.drawable.rounded_red_border10)

            } else {
                binding.edUser.background = getDrawable(R.drawable.rounded_white_border10)
                binding.edKeyPin.background = getDrawable(R.drawable.rounded_white_border10)
                val userRequest = userLoginRequest()
                Log.e("login Request===", userRequest.toString())
                Helper.showProgressMessage(this@LoginAct, getString(R.string.please_wait))
                loginViewModel.userLogin(userRequest,this@LoginAct)
            }

        }

        bindObservers()

    }


    private fun userLoginRequest(): Map<String, String> {
        return binding.run {
            mapOf(
                "NombreUsuario" to binding.edUser.text.toString(),
                "ClaveUsuario" to binding.edKeyPin.text.toString(),
                "DesconectarOtroPuesto" to "true",
                "CodigoDobleFactor" to ""
            )

        }
    }


    private fun bindObservers() {
        loginViewModel.userLoginLiveData.observe(this) { it ->
            Helper.hideProgressMessage()
            when (it) {
                is NetworkResult.Success -> {
                    it.data?.let {
                        val jsonObject = JSONObject(it.string())
                        Log.e("user login Response===", jsonObject.toString())
                        if (jsonObject.getInt("ErrorCode") == 0) {
                            binding.tvError.visibility = View.GONE
                            sharedPrf.setStoredTag(SharedPrf.LOGIN, "true")
                            sharedPrf.setStoredTag(SharedPrf.USER_ID,jsonObject.getJSONObject("Response").getInt("IdUser").toString() )
                            sharedPrf.setStoredTag(SharedPrf.USER_NAME,jsonObject.getJSONObject("Response").getString("UserName") )
                            startActivity(Intent(this, HomeAct::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                            finish()
                        } else {
                            if(jsonObject.getInt("ErrorCode")==2){
                                otherUserConnectionDialog()
                            }
                            else{
                                binding.tvError.visibility = View.VISIBLE
                                binding.tvError.text = jsonObject.getString("Message")
                            }
                        }
                        //  Log.e("TAG", "observers: $it.")
                    }

                }

                is NetworkResult.Error -> {
                    Toast.makeText(
                        this@LoginAct,
                        "" + it.message.toString(),
                        Toast.LENGTH_SHORT
                    ).show()
                }

                is NetworkResult.Loading -> {
                    Helper.showProgressMessage(this@LoginAct, getString(R.string.please_wait))
                }

                else -> {}
            }
        }


    }


    private fun forgetServerDialog() {
        val dialogView =
            LayoutInflater.from(this@LoginAct).inflate(R.layout.dialog_forget_server, null)
        val dialogBuilder = AlertDialog.Builder(this@LoginAct).setView(dialogView)

        val alertDialog = dialogBuilder.create()

        // Apply custom rounded corner background
        alertDialog.window?.setBackgroundDrawableResource(R.drawable.dialog_rounded_bg)

        // Set listeners or actions if needed
        val btnCancel: Button = dialogView.findViewById(R.id.btnCancel)
        val btnYes: Button = dialogView.findViewById(R.id.btnYes)

        btnCancel.setOnClickListener {
            alertDialog.dismiss()
        }

        btnYes.setOnClickListener {
            alertDialog.dismiss()
            sharedPrf.clearAll()
            startActivity(Intent(this@LoginAct, SplashAct::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            finish()
        }


        // Show the dialog
        alertDialog.show()
    }

    private fun otherUserConnectionDialog() {
        val dialogView =
            LayoutInflater.from(this@LoginAct).inflate(R.layout.dialog_other_user_connection, null)
        val dialogBuilder = AlertDialog.Builder(this@LoginAct).setView(dialogView)

        val alertDialog = dialogBuilder.create()

        // Apply custom rounded corner background
        alertDialog.window?.setBackgroundDrawableResource(R.drawable.dialog_rounded_bg)

        // Set listeners or actions if needed
        val btnNo: Button = dialogView.findViewById(R.id.btnNo)
        val btnYeah: Button = dialogView.findViewById(R.id.btnYeah)

        btnNo.setOnClickListener {
            alertDialog.dismiss()
            closeSessionDialog()
        }

        btnYeah.setOnClickListener {
            alertDialog.dismiss()
        }


        // Show the dialog
        alertDialog.show()
    }

    private fun closeSessionDialog() {
        val dialogView =
            LayoutInflater.from(this@LoginAct).inflate(R.layout.dialog_close_session, null)
        val dialogBuilder = AlertDialog.Builder(this@LoginAct).setView(dialogView)

        val alertDialog = dialogBuilder.create()

        // Apply custom rounded corner background
        alertDialog.window?.setBackgroundDrawableResource(R.drawable.dialog_rounded_bg)

        // Set listeners or actions if needed
        val btnUnderstood: Button = dialogView.findViewById(R.id.btnUnderstood)

        btnUnderstood.setOnClickListener {
            alertDialog.dismiss()
        }


        // Show the dialog
        alertDialog.show()
    }


}