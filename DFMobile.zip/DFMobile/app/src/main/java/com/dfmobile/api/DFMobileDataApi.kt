package com.dfmobile.api

import com.dfmobile.utils.Constants.LOGIN_API
import com.dfmobile.utils.Constants.USER_CONFIGURATION_API
import com.dfmobile.utils.Constants.USER_LOGOUT_API
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.FieldMap
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import retrofit2.http.Url

interface DFMobileDataApi {

    @GET
    suspend fun serverConnectionApi(@Url url :String): Response<ResponseBody>

    @FormUrlEncoded
    @POST(LOGIN_API)
    suspend fun loginApi(@FieldMap params: Map<String, String>): Response<ResponseBody>

    @GET(USER_CONFIGURATION_API)
    suspend fun userConfigurationApi(@Query("idUsuario") userId: String): Response<ResponseBody>

    @POST(USER_LOGOUT_API)
    suspend fun userLogoutApi(): Response<ResponseBody>


}