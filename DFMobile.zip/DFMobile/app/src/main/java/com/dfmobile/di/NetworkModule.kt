package com.dfmobile.di

import android.util.Log
import com.dfmobile.BuildConfig
import com.dfmobile.api.AuthInterceptor
import com.dfmobile.api.DFMobileDataApi
import com.dfmobile.utils.SharedPrf
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Inject
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
class NetworkModule {

    @Inject
    lateinit var baseUrlProvider: BaseUrlProvider

    @Singleton
    @Provides
    fun providesRetrofitBuilder(sharedPrf: SharedPrf): Retrofit.Builder {
        baseUrlProvider = BaseUrlProvider(sharedPrf)
        Log.e("base url ===",baseUrlProvider.getBaseUrl())
        val baseUrl = if(sharedPrf.getStoredTag(SharedPrf.DYNAMIC_BASE_URL)=="")
            "https://local.df-server.info:24003/mmobile_3/" else baseUrlProvider.getBaseUrl()


        return Retrofit.Builder()
            .baseUrl(baseUrl)  // You can add logic with sharedPrf if needed
            .addConverterFactory(GsonConverterFactory.create())
    }

    @Singleton
    @Provides
    fun provideOkHttpClient(interceptor: AuthInterceptor): OkHttpClient {
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.level = if (BuildConfig.DEBUG) {
            HttpLoggingInterceptor.Level.BODY
        } else {
            HttpLoggingInterceptor.Level.NONE
        }

        return OkHttpClient.Builder()
            .addInterceptor(interceptor)
            .addInterceptor(loggingInterceptor) // Add logging interceptor
            .build()
    }

    @Singleton
    @Provides
    fun providesUserDataAPI(retrofitBuilder: Retrofit.Builder, okHttpClient: OkHttpClient): DFMobileDataApi {
        return retrofitBuilder.client(okHttpClient).build().create(DFMobileDataApi::class.java)
    }
}
