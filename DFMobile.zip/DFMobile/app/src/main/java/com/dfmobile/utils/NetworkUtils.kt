package com.dfmobile.utils

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.widget.Toast

object NetworkUtils {
    private var networkReceiver: NetworkReceiver? = null

    // Function to check if network is available
    fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val activeNetwork = connectivityManager.activeNetwork
            val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
            networkCapabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        } else {
            val networkInfo = connectivityManager.activeNetworkInfo
            networkInfo != null && networkInfo.isConnected
        }
    }

    // Function to register the network receiver in Application class
    fun registerNetworkReceiver(context: Context) {
        if (networkReceiver == null) {
            networkReceiver = NetworkReceiver(context)
        }
        val filter = IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
        context.registerReceiver(networkReceiver, filter)
    }

    // Function to unregister the network receiver
    fun unregisterNetworkReceiver(context: Context) {
        networkReceiver?.let {
            context.unregisterReceiver(it)
        }
    }

    // NetworkReceiver class to handle network status changes
    class NetworkReceiver(private val context: Context) : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val connectivityManager = context?.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val activeNetwork = connectivityManager.activeNetworkInfo

            if (activeNetwork == null || !activeNetwork.isConnected) {
                Toast.makeText(context, "Network is closed", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "Network is available", Toast.LENGTH_LONG).show()
            }
        }
    }

}