package com.dfmobile.utils

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.text.TextUtils
import android.util.Patterns
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import com.dfmobile.R
import java.io.ByteArrayOutputStream
import java.lang.Exception
import android.provider.Settings
import java.util.UUID

class Helper {
    companion object {

        private var mDialog: Dialog? = null
        private var isProgressDialogRunning = false

        fun isValidEmail(email: String): Boolean {
            return !TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches()
        }

        fun hideKeyboard(view: View){
            try {
                val imm = view.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(view.windowToken, 0)
            }catch (e: Exception){
              e.printStackTrace()
            }
        }


        fun showProgressMessage(dialogActivity: Activity?, msg: String?) {
            try {
                if (isProgressDialogRunning) {
                    hideProgressMessage()
                }
                isProgressDialogRunning = true
                mDialog = Dialog(dialogActivity!!)
                mDialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
                mDialog!!.setContentView(R.layout.dialog_loading)
                mDialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                val lp = mDialog!!.window!!.attributes
                lp.dimAmount = 0.0f
                mDialog!!.window!!.attributes = lp
                mDialog!!.window!!.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
               // mDialog!!.findViewById<TextView>(R.id.loading_text).text = msg
                mDialog!!.setCancelable(true)
                mDialog!!.setCanceledOnTouchOutside(true)
                mDialog!!.show()
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }

        fun hideProgressMessage() {
            isProgressDialogRunning = true
            try {
                if (mDialog != null) {
                    mDialog!!.dismiss()
                }
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }


        fun getImageUri(inContext: Context, inImage: Bitmap): Uri? {
            val bytes = ByteArrayOutputStream()
            inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
            val path = MediaStore.Images.Media.insertImage(
                inContext.contentResolver,
                inImage,
                "Title" + System.currentTimeMillis(),
                null
            )
            return Uri.parse(path)
        }





        fun getDeviceSerial(context: Context): String {
            var physicalSerial = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            if (physicalSerial == null || physicalSerial.isEmpty()) {
// Fallback to another unique identifier randomly generated if no physical serial is found
                val uuid = UUID.randomUUID().toString() // Generates a UUID
                physicalSerial = uuid.replace("-", "").substring(0, 16)
            }
// We put hyphens to make it conform to our standard
            physicalSerial = physicalSerial.substring(0, 4) + "-" + physicalSerial.substring(4, 8) + "-" +
                    physicalSerial.substring(8, 12) + "-" + physicalSerial.substring(12, 16)
            physicalSerial = physicalSerial.uppercase()
            return physicalSerial
        }



    }




}