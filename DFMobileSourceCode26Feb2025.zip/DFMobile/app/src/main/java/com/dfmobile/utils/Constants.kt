package com.dfmobile.utils

object Constants {


    const val TAG = "DFMobile"
    //const val BASE_URL = "https://local.df-server.info:24003/mmobile_3/api/"
   // var BASE_URL = "https://local.df-server.info:24003/mmobile_3/"


    const val GET_WS_CONNECTION_API: String = "api/WS/Disponible"


    const val LOGIN_API: String = "api/Usuarios/LogIn"

    const val USER_CONFIGURATION_API: String = "api/Usuarios/Configuracion"

    const val USER_LOGOUT_API: String = "api/Usuarios/LogOut"

    const val USER_FEATURES_API: String = "api/Usuarios/Funcionalidades"

    const val INDEX_FILLING_API: String = "api/Usuarios/FijarConfiguracion"

    const val ASK_NAME_API: String = "api/Usuarios/FijarConfiguracion"

    const val RENAME_PATTERN_API: String = "api/Usuarios/FijarConfiguracion"





    const val USER_TOKEN = "user_token"
    const val PREFS_TOKEN_FILE = "prefs_token_file"
    val BG_COLORS = arrayOf("#fef9ed", "#f2f8ff", "#edffee", "#fce9ff")




}