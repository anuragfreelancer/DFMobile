package com.dfmobile.ui.setting

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.dfmobile.R
import com.dfmobile.databinding.ActivityUserSettingBinding
import com.dfmobile.ui.connection.SplashAct
import com.dfmobile.ui.login.LoginAct
import com.dfmobile.ui.setting.askname.AskName1Act
import com.dfmobile.ui.setting.features.FeaturesAct
import com.dfmobile.ui.setting.indexfilling.IndexFillingAct
import com.dfmobile.ui.setting.renamingpatten.RenamingPatternAct
import com.dfmobile.utils.Constants
import com.dfmobile.utils.Helper
import com.dfmobile.utils.NetworkResult
import com.dfmobile.utils.PreferenceConnector
import com.dfmobile.utils.SharedPrf
import com.dfmobile.viewmodel.ConfigurationViewModel
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject

@AndroidEntryPoint
class ConfigurationAct : AppCompatActivity(), Helper.Companion.ServiceUnreachableDialogCallback {
    private lateinit var binding : ActivityUserSettingBinding
    private lateinit var configurationViewModel: ConfigurationViewModel

    private var askName : String =""
    private var fillIndex : String =""
    private var pattern : String =""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_user_setting)
        configurationViewModel = ViewModelProvider(this)[ConfigurationViewModel::class.java]

        initViews()
    }

    private fun initViews() {

        binding.tvUser.text = getString(R.string.users)+PreferenceConnector.getStoredTag(this@ConfigurationAct,PreferenceConnector.USER_NAME,"")
        var server = removeTrailingSlash(PreferenceConnector.getStoredTag(this@ConfigurationAct,PreferenceConnector.DYNAMIC_BASE_URL,""))


        binding.tvServer.text = getString(R.string.server)+ server


        binding.ivBack.setOnClickListener {
            finish()
        }


        binding.btnLogout.setOnClickListener {
            logoutDialog()
        }

        binding.rlFeatures.setOnClickListener {
           startActivity(Intent(this@ConfigurationAct,FeaturesAct::class.java))
        }

        binding.ivFeatures.setOnClickListener {
            startActivity(Intent(this@ConfigurationAct,FeaturesAct::class.java))
        }


        binding.rlNamePattern.setOnClickListener {
            startActivity(Intent(this@ConfigurationAct,RenamingPatternAct::class.java)
                .putExtra("pattern",binding.tvPattern.text.toString())
                .putExtra("askName",askName)
                .putExtra("fillIndex",fillIndex))
        }

        binding.rlAskName.setOnClickListener {
            startActivity(Intent(this@ConfigurationAct,AskName1Act::class.java)
                .putExtra("pattern",binding.tvPattern.text.toString())
                .putExtra("askName",askName)
                .putExtra("fillIndex",fillIndex))
        }

        binding.rlIndex.setOnClickListener {
            startActivity(Intent(this@ConfigurationAct,IndexFillingAct::class.java)
                .putExtra("pattern",binding.tvPattern.text.toString())
                .putExtra("askName",askName)
                .putExtra("fillIndex",fillIndex))
        }


        bindObservers()



    }


    fun removeTrailingSlash(url: String): String {
        return if (url.endsWith("/")) {
            url.dropLast(1)  // Removes the last character if it's a "/"
        } else {
            url
        }
    }


    private fun bindObservers() {
        configurationViewModel.configurationLiveData.observe(this) {it->
            Helper.hideProgressMessage()
            when (it) {
                is NetworkResult.Success -> {
                    it.data?.let {
                        val jsonObject = JSONObject(it.string())
                        Log.e("user configuration Response===",jsonObject.toString())
                        if (jsonObject.getInt("ErrorCode")==0) {

                            if(jsonObject.getJSONObject("Response").getBoolean("PedirNombre"))
                            {
                                binding.tvRequestName.text = getString(R.string.yes_ask_me)
                                askName = "true"

                            }
                             else {
                                 binding.tvRequestName.text = getString(R.string.no_i_dont_ask_me)
                                askName = "false"
                            }



                            if(jsonObject.getJSONObject("Response").getInt("RellenarIndices")==1){
                                binding.tvIndices.text = getString(R.string.always_fill_in_index)
                                fillIndex = "1"

                            }
                            else if(jsonObject.getJSONObject("Response").getInt("RellenarIndices")==2)
                            {
                                binding.tvIndices.text = getString(R.string.ask_me_upload_a_document)
                                fillIndex = "2"

                            }
                            else {
                                binding.tvIndices.text = getString(R.string.do_not_fill_in_indices)
                                fillIndex = "3"
                            }

                            pattern = jsonObject.getJSONObject("Response").getString("PatronNombre")
                            binding.tvPattern.text = pattern



                        }

                        else if(jsonObject.getInt("ErrorCode")==-998){
                            Helper.closeSessionDialog(this@ConfigurationAct)

                        }



                        else {
                            Toast.makeText(
                                this@ConfigurationAct,
                                "" + jsonObject.getString("message"),
                                Toast.LENGTH_SHORT
                            ).show()




                        }

                    }




                }

                is NetworkResult.Error -> {
                    if(it.message.toString()=="Service is unreachable"){
                        Toast.makeText(
                            this@ConfigurationAct,
                            getString(R.string.server_error),
                            Toast.LENGTH_SHORT
                        ).show()                    }
                    else {
                        Toast.makeText(
                            this@ConfigurationAct,
                            "" + it.message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                }

                is NetworkResult.Loading -> {
                    Helper.showProgressMessage(this@ConfigurationAct,getString(R.string.please_wait))
                }

                else -> {}
            }
        }


        configurationViewModel.logoutLiveData.observe(this) {it->
            Helper.hideProgressMessage()
            when (it) {
                is NetworkResult.Success -> {
                    it.data?.let {
                        val jsonObject = JSONObject(it.string())
                        Log.e("user logout Response===",jsonObject.toString())
                        if (jsonObject.getInt("ErrorCode")==0) {
                           // sharedPrf.clearAll()
                            PreferenceConnector.clearAll(this@ConfigurationAct)
                            startActivity(Intent(this@ConfigurationAct, SplashAct::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                            finish()
                        } else {
                            Toast.makeText(
                                this@ConfigurationAct,
                                "" + jsonObject.getString("message"),
                                Toast.LENGTH_SHORT
                            ).show()

                        }

                    }


                }

                is NetworkResult.Error -> {


                    if(it.message.toString()=="Service is unreachable"){
                      //  Helper.serviceUnreachableDialog(this@ConfigurationAct, this@ConfigurationAct)
                    }
                    else {
                        Toast.makeText(
                            this@ConfigurationAct,
                            "" + it.message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }


                }

                is NetworkResult.Loading -> {
                    Helper.showProgressMessage(this@ConfigurationAct,getString(R.string.please_wait))
                }

                else -> {}
            }
        }


    }


    private fun logoutDialog() {
        val dialogView =
            LayoutInflater.from(this@ConfigurationAct).inflate(R.layout.dialog_logout, null)
        val dialogBuilder = AlertDialog.Builder(this@ConfigurationAct).setView(dialogView)

        val alertDialog = dialogBuilder.create()

        // Apply custom rounded corner background
        alertDialog.window?.setBackgroundDrawableResource(R.drawable.dialog_rounded_bg)

        // Set listeners or actions if needed
        val btnCancel: Button = dialogView.findViewById(R.id.btnCancel)

        val btnClose: Button = dialogView.findViewById(R.id.btnClose)


        btnCancel.setOnClickListener {
            alertDialog.dismiss()
        }

        btnClose.setOnClickListener {
            alertDialog.dismiss()
           // configurationViewModel.userLogout(this@ConfigurationAct)
          //  sharedPrf.clearAll()
            PreferenceConnector.clearAll(this@ConfigurationAct)
            startActivity(Intent(this@ConfigurationAct, LoginAct::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            finish()
        }


        // Show the dialog
        alertDialog.show()
    }

    override fun onRetryClicked(tag:String) {
      //  configurationViewModel.userConfiguration(sharedPrf.getStoredTag(SharedPrf.USER_ID),this@ConfigurationAct)
    }


    override fun onResume() {
        super.onResume()
      //  configurationViewModel.userConfiguration(sharedPrf.getStoredTag(SharedPrf.USER_ID),this@ConfigurationAct)

        configurationViewModel.userConfiguration(PreferenceConnector.getStoredTag(this@ConfigurationAct,PreferenceConnector.DYNAMIC_BASE_URL,"") +
                Constants.USER_CONFIGURATION_API,PreferenceConnector.getStoredTag(this@ConfigurationAct,PreferenceConnector.USER_ID,""),this@ConfigurationAct)

    }

}