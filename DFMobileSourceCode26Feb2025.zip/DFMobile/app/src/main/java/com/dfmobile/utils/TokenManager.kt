package com.dfmobile.utils

import android.content.Context
import com.dfmobile.utils.Constants.USER_TOKEN
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class TokenManager @Inject constructor(@ApplicationContext private val context: Context) {


    fun saveToken(token: String) {
     // sharedPrf.setStoredTag(USER_TOKEN,token)
        PreferenceConnector.setStoredTag(context,PreferenceConnector.USER_TOKEN, token)

    }

    fun getToken(): String? {
       // return sharedPrf.getStoredTag(USER_TOKEN)
        return  PreferenceConnector.getStoredTag(context,PreferenceConnector.USER_TOKEN, "")

    }
}