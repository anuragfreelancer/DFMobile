package com.dfmobile.api

import com.dfmobile.utils.Constants.ASK_NAME_API
import com.dfmobile.utils.Constants.INDEX_FILLING_API
import com.dfmobile.utils.Constants.LOGIN_API
import com.dfmobile.utils.Constants.RENAME_PATTERN_API
import com.dfmobile.utils.Constants.USER_CONFIGURATION_API
import com.dfmobile.utils.Constants.USER_FEATURES_API
import com.dfmobile.utils.Constants.USER_LOGOUT_API
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.FieldMap
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Url

interface DFMobileDataApi {

    @GET
    suspend fun serverConnectionApi(@Url url :String): Response<ResponseBody>

    @POST
    suspend fun loginApi(@Url url :String, @Body requestBody: Map<String, String> ): Response<ResponseBody>

    @GET
    suspend fun userConfigurationApi(@Url url :String,@Query("idUsuario") userId: String): Response<ResponseBody>

    @POST(USER_LOGOUT_API)
    suspend fun userLogoutApi(): Response<ResponseBody>

    @GET
    suspend fun userFeaturesApi(@Url url :String,@Query("idUsuario") userId: String): Response<ResponseBody>

    @PUT
    suspend fun indexFillingApi(@Url url :String, @Body requestBody: Map<String, String>): Response<ResponseBody>

    @PUT
    suspend fun askNameApi(@Url url :String, @Body requestBody: Map<String, String>): Response<ResponseBody>

    @PUT
    suspend fun renamingPatternApi(@Url url :String, @Body requestBody: Map<String, String>): Response<ResponseBody>

}