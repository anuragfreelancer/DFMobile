package com.dfmobile.di

import android.content.Context
import android.util.Log
import com.dfmobile.BuildConfig
import com.dfmobile.api.AuthInterceptor
import com.dfmobile.api.DFMobileDataApi
import com.dfmobile.utils.PreferenceConnector
import com.dfmobile.utils.RetrofitManager
import com.dfmobile.utils.SharedPrf
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Inject
import javax.inject.Singleton
import java.util.concurrent.TimeUnit


@InstallIn(SingletonComponent::class)
@Module
class NetworkModule {

    @Inject
    lateinit var baseUrlProvider: BaseUrlProvider


    @Provides
    @Singleton
    fun provideRetrofitManager(@ApplicationContext context: Context): RetrofitManager {
        baseUrlProvider = BaseUrlProvider(context)
        return RetrofitManager(baseUrlProvider)
    }

    @Provides
    @Singleton
    fun provideOkHttpClient(interceptor: AuthInterceptor): OkHttpClient {
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.level = if (BuildConfig.DEBUG) {
            HttpLoggingInterceptor.Level.BODY
        } else {
            HttpLoggingInterceptor.Level.NONE
        }

        return OkHttpClient.Builder()
            .addInterceptor(interceptor)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor)
            .build()
    }

    // Provides the API service using the Retrofit instance
    @Provides
    @Singleton
    fun provideApiService(retrofitManager: RetrofitManager, okHttpClient: OkHttpClient): DFMobileDataApi {
        val retrofit = retrofitManager.getRetrofit()  // Always create a new instance
        return retrofit.newBuilder()
            .client(okHttpClient)  // Add the OkHttpClient
            .build()
            .create(DFMobileDataApi::class.java)
    }
}