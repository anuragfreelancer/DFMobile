package com.dfmobile.utils

import android.app.Application
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@InstallIn(SingletonComponent::class)
@Module
class SharedPrfModule {

    @Provides
    @Singleton
    fun provideSharedPrf(application: Application): SharedPrf {
        return SharedPrf(application.applicationContext)
    }
}