package com.dfmobile.ui.setting.features

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.dfmobile.R
import com.dfmobile.databinding.ItemFeatureBinding
import com.dfmobile.model.FeaturesModel


class FeatureAdapter (
    private val mContext: Context,
                          var arrayList: ArrayList<FeaturesModel.Response>?,
) : RecyclerView.Adapter<FeatureAdapter.MyViewHolder>() {



    class MyViewHolder(var binding: ItemFeatureBinding) :
        RecyclerView.ViewHolder(binding.root)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding: ItemFeatureBinding = DataBindingUtil.inflate(
            LayoutInflater.from(mContext), R.layout.item_feature, parent, false
        )
        return MyViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return arrayList!!.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
         holder.binding.tvName.text = arrayList!![position].Nombre

        if (arrayList!![position].Valor) holder.binding.ivImg.setImageResource(R.drawable.ic_select)
         else  holder.binding.ivImg.setImageResource(R.drawable.ic_unselect)

        holder.itemView.setOnClickListener {
        }
    }
}