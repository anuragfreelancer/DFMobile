package com.dfmobile.di

import android.content.Context
import com.dfmobile.utils.PreferenceConnector
import com.dfmobile.utils.SharedPrf
import javax.inject.Inject


class BaseUrlProvider @Inject constructor(private val context: Context) {

    fun getBaseUrl(): String {
        // Access shared preferences via SharedPrf
        val baseUrl = if(PreferenceConnector.getStoredTag(context,PreferenceConnector.DYNAMIC_BASE_URL,"").equals("") )  "https://local.df-server.info:24003"
        else PreferenceConnector.getStoredTag(context,PreferenceConnector.DYNAMIC_BASE_URL,"")
        return if (baseUrl.endsWith("/")) {
            baseUrl
        } else {
            "$baseUrl/"
        }
    }
}




