package com.dfmobile.model

import com.google.gson.annotations.SerializedName

data class FeaturesModel(
    val ErrorCode: Int,
    val Message: String,
    @SerializedName("Response") val response: List<Response>){
    data class Response(
        val Nombre: String,
        val Tipo: Int,
        val Valor: Boolean
    )
}