package com.dfmobile.ui.setting.renamingpatten

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.dfmobile.R
import com.dfmobile.databinding.ActivityIndexFillingBinding
import com.dfmobile.databinding.ActivityRenamingPatternBinding
import com.dfmobile.ui.connection.SplashAct
import com.dfmobile.utils.Constants
import com.dfmobile.utils.Helper
import com.dfmobile.utils.NetworkResult
import com.dfmobile.utils.PreferenceConnector
import com.dfmobile.utils.SharedPrf
import com.dfmobile.viewmodel.IndexFillingViewModel
import com.dfmobile.viewmodel.RenamingViewModel
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject

@AndroidEntryPoint
class RenamingPatternAct : AppCompatActivity(),Helper.Companion.ServiceUnreachableDialogCallback {

    private lateinit var binding : ActivityRenamingPatternBinding
    private lateinit var renamingViewModel: RenamingViewModel
    private var askName : String =""
    private var fillIndex : String =""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_renaming_pattern)
        renamingViewModel = ViewModelProvider(this)[RenamingViewModel::class.java]

        initViews()
    }

    private fun initViews() {

        if (intent!=null){

            binding.edPattern.setText(intent.getStringExtra("pattern"))
            askName = intent.getStringExtra("askName")!!
            fillIndex = intent.getStringExtra("fillIndex")!!

        }

        binding.ivBack.setOnClickListener {
            finish()
        }


        binding.tvKeep.setOnClickListener {
           if(binding.edPattern.text.toString().isEmpty()){

           }
            else{
                val renamingPatternRequest = renamingPatternRequest(PreferenceConnector.getStoredTag(this@RenamingPatternAct,PreferenceConnector.USER_ID,""),askName,binding.edPattern.text.toString(),fillIndex)
               Log.e("renamingPatternRequest Request===", renamingPatternRequest.toString())
               Helper.showProgressMessage(this@RenamingPatternAct, getString(R.string.please_wait))
               val urlRequest = "?idUsuario="+ PreferenceConnector.getStoredTag(this@RenamingPatternAct,PreferenceConnector.USER_ID,"")+"&pedirNombre="+ askName+"&patronNombre="+ binding.edPattern.text.toString() +"&rellenarIndices="+  fillIndex
               renamingViewModel.setRenamingPattern(PreferenceConnector.getStoredTag(this@RenamingPatternAct,PreferenceConnector.DYNAMIC_BASE_URL,"") + Constants.RENAME_PATTERN_API+ urlRequest,renamingPatternRequest,this@RenamingPatternAct)

           }
        }


        bindObservers()



    }

    private fun bindObservers() {
        renamingViewModel.patternLiveData.observe(this) {it->
            Helper.hideProgressMessage()
            when (it) {
                is NetworkResult.Success -> {
                    it.data?.let {
                        val jsonObject = JSONObject(it.string())
                        Log.e("user rename pattern Response===",jsonObject.toString())
                        if (jsonObject.getInt("ErrorCode")==0) {
                            finish()
                        }

                        else if(jsonObject.getInt("ErrorCode")==-998){
                            Helper.closeSessionDialog(this@RenamingPatternAct)

                        }


                        else {
                            Toast.makeText(
                                this@RenamingPatternAct,
                                "" + jsonObject.getString("message"),
                                Toast.LENGTH_SHORT
                            ).show()


                        }
                    }
                }

                is NetworkResult.Error -> {
                    if(it.message.toString()=="Service is unreachable"){
                        Toast.makeText(
                            this@RenamingPatternAct,
                            getString(R.string.server_error),
                            Toast.LENGTH_SHORT
                        ).show()                    }
                    else {
                        Toast.makeText(
                            this@RenamingPatternAct,
                            "" + it.message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                }

                is NetworkResult.Loading -> {
                    Helper.showProgressMessage(this@RenamingPatternAct,getString(R.string.please_wait))
                }

                else -> {}
            }
        }




    }

    override fun onRetryClicked(tag:String) {
        // indexFillingViewModel.setIndexFilling(sharedPrf.getStoredTag(SharedPrf.USER_ID),this@IndexFillingAct)
    }


    private fun renamingPatternRequest(userId:String,askName:String,pattern:String,fillIndex:String): Map<String, String> {
        return binding.run {
            mapOf(
                "idUsuario" to userId,
                "pedirNombre" to askName,
                "patronNombre" to pattern,
                "rellenarIndices" to fillIndex
            )

        }
    }

}