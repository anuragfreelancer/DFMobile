package com.dfmobile.ui.connection

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.dfmobile.R
import com.dfmobile.databinding.ActivitySelectTypeBinding

class SelectServerTypeAct : AppCompatActivity() {
    private lateinit var binding : ActivitySelectTypeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_select_type)
        initViews()
    }

    private fun initViews() {

        binding.ivBack.setOnClickListener {  }


        binding.btnQr.setOnClickListener {
            startActivity(Intent(this@SelectServerTypeAct,QrCodeScannerAct::class.java))
        }

        binding.btnURL.setOnClickListener {
            startActivity(Intent(this@SelectServerTypeAct,UrlAct::class.java))
        }

    }
}