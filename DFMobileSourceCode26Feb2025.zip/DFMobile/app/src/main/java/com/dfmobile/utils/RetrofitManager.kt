package com.dfmobile.utils

import com.dfmobile.di.BaseUrlProvider
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Inject

class RetrofitManager @Inject constructor(
    private val baseUrlProvider: BaseUrlProvider
) {

    // Method to get Retrofit instance, always using the latest base URL
    fun getRetrofit(): Retrofit {
        val baseUrl = baseUrlProvider.getBaseUrl()

        // Create a new Retrofit instance with the updated base URL each time
        return Retrofit.Builder()
            .baseUrl(baseUrl)  // Always use the most recent base URL
            .addConverterFactory(GsonConverterFactory.create())
            .build()  // Return a new Retrofit instance
    }
}
