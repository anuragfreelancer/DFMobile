package com.dfmobile.ui.connection

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.dfmobile.R
import com.dfmobile.databinding.ActivityScanQrCodeBinding
import com.dfmobile.di.NetworkModule
import com.dfmobile.ui.login.LoginAct
import com.dfmobile.utils.Constants
import com.dfmobile.utils.Helper
import com.dfmobile.utils.NetworkResult
import com.dfmobile.utils.NetworkUtils
import com.dfmobile.utils.PreferenceConnector
import com.dfmobile.utils.SharedPrf
import com.dfmobile.viewmodel.ConnectionViewModel
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject
import javax.inject.Inject

@AndroidEntryPoint
class QrCodeScannerAct : AppCompatActivity(),Helper.Companion.ServiceUnreachableDialogCallback {
    private lateinit var binding: ActivityScanQrCodeBinding
    private lateinit var vibrator: Vibrator
    private lateinit var connectionViewModel: ConnectionViewModel
    private var scannedQRCode: String = ""
    private val sharedPrf by lazy { SharedPrf(this) }

   // @Inject
  //  lateinit var sharedPrf: SharedPrf



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_scan_qr_code)
        connectionViewModel = ViewModelProvider(this)[ConnectionViewModel::class.java]
        //sharedPrf = SharedPrf(this@QrCodeScannerAct)

        initViews()
    }

    private fun initViews() {

        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        // Enable beep sound when QR code is scanned
        binding.scannerView.isSoundEffectsEnabled = true

        binding.ivBack.setOnClickListener { finish() }

        binding.ivRefresh.setOnClickListener {
            binding.scannerView.resume()
        }

        startQRCodeScanner()


        bindObservers()
    }


    private fun startQRCodeScanner() {
        // Configure the scanner view
        binding.scannerView.decodeContinuous { result ->
            if (result != null) {
                // Handle the scanned QR code data
                scannedQRCode = result.text
                // showScannedData(scannedQRCode)
                vibrateDevice()
                Log.e("qr code data===", scannedQRCode)

                // Pause the scanner to reset it
                binding.scannerView.pause()

                if(!scannedQRCode.endsWith("/")){
                    scannedQRCode = "$scannedQRCode/"
                    //  baseUrl = baseUrl.trimEnd('/')
                } /*else {

                            }*/
                Log.e(" clean base url ===",scannedQRCode)

                binding.scannerView.visibility = View.GONE
                if (NetworkUtils.isNetworkAvailable(this@QrCodeScannerAct))
                    connectionViewModel.serverConnection(scannedQRCode+Constants.GET_WS_CONNECTION_API,this@QrCodeScannerAct)
                else {
                    binding.scannerView.visibility = View.VISIBLE
                    binding.scannerView.resume()
                    Toast.makeText(this@QrCodeScannerAct,getString(R.string.network_not_available), Toast.LENGTH_LONG).show()
                }


                // Delay a little to give time for the vibration, then resume the scanner
                Handler(Looper.getMainLooper()).postDelayed({
                    binding.scannerView.resume()
                    //binding.tvError.text = ""
                 //   binding.tvError.visibility = View.GONE
                }, 1000) // Delay of 1 second to allow for vibration
            }
        }
        binding.scannerView.resume()  // Start camera preview

    }



    private fun vibrateDevice() {
        // Vibrate the device for 500 milliseconds
        if (vibrator.hasVibrator()) {
            vibrator.vibrate(500) // Vibrates for 500ms
        }
    }


    override fun onResume() {
        super.onResume()
        binding.scannerView.resume()  // Start camera preview when activity is resumed
        binding.tvError.text = ""
        binding.tvError.visibility = View.GONE

    }

    override fun onPause() {
        super.onPause()
        binding.scannerView.pause()  // Pause the scanner when the activity is paused
    }


    private fun bindObservers() {
        connectionViewModel.serverConnectionLiveData.observe(this) { it ->
            Helper.hideProgressMessage()
            when (it) {
                is NetworkResult.Success -> {
                    it.data?.let {
                        val jsonObject = JSONObject(it.string())
                        Log.e("server connection Response===", jsonObject.toString())
                        if (jsonObject.getInt("ErrorCode") == 0) {

                            binding.tvError.visibility = View.GONE
                            binding.tvUrl.visibility = View.GONE
                           // sharedPrf.setStoredTag(SharedPrf.DYNAMIC_BASE_URL,scannedQRCode)

                           // val networkModule = NetworkModule()
                          //  networkModule.rebuildRetrofit(this@QrCodeScannerAct)
                            PreferenceConnector.setStoredTag(this@QrCodeScannerAct,
                                PreferenceConnector.DYNAMIC_BASE_URL, scannedQRCode)

                            startActivity(Intent(this@QrCodeScannerAct, LoginAct::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                            finish()

                        } else {
                           // binding.tvError.visibility = View.VISIBLE
                            binding.scannerView.visibility = View.VISIBLE
                            binding.tvError.visibility = View.VISIBLE
                            binding.tvError.text =  jsonObject.getString("message")
                        }

                    }


                }

                is NetworkResult.Error -> {
                    Log.e("error=====", it.message.toString())
                  //  binding.tvError.visibility = View.VISIBLE
                 //   binding.tvError.text =  it.message.toString()

                    if(it.message.toString()=="Service is unreachable"){
                       // Helper.serviceUnreachableDialog(this@QrCodeScannerAct, this@QrCodeScannerAct)
                        binding.scannerView.resume()  // Start camera preview when activity is resumed
                        binding.scannerView.visibility = View.VISIBLE
                        binding.tvError.visibility = View.VISIBLE
                        binding.tvError.text =  getString(R.string.invalid_url)
                    }
                    /*else {
                        binding.tvError.visibility = View.VISIBLE
                        binding.tvError.text =  it.message.toString()
                    }*/


                }

                is NetworkResult.Loading -> {
                    Helper.showProgressMessage(
                        this@QrCodeScannerAct,
                        getString(R.string.please_wait)
                    )
                }

                else -> {}
            }
        }


    }

    override fun onRetryClicked(tag:String) {
        Log.e(" clean base url ===",scannedQRCode)
      // if(tag=="retry") connectionViewModel.serverConnection(scannedQRCode+Constants.GET_WS_CONNECTION_API,this@QrCodeScannerAct)
    }


}