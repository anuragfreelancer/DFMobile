package com.dfmobile.api

import android.util.Log
import com.dfmobile.utils.TokenManager
import okhttp3.Interceptor
import okhttp3.Response
import javax.inject.Inject

class AuthInterceptor @Inject constructor() : Interceptor {

    @Inject
    lateinit var tokenManager: TokenManager

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request().newBuilder()

        val token = tokenManager.getToken()
        request.addHeader("api_key", "DFServerMMobile3")
        request.addHeader("serial", token!!)
        request.addHeader("Accept", "application/json")


       // request.addHeader("Authorization", token!!)
       // request.addHeader("Authorization", "Bearer $token")

      //  Log.e("User Token====","Bearer $token")

        Log.e("Serial number====",token)

        return chain.proceed(request.build())
    }
}