package com.dfmobile.viewmodel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dfmobile.repository.DFMobileDataRepository
import com.dfmobile.utils.NetworkResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import javax.inject.Inject




@HiltViewModel
class AskNameViewModel @Inject constructor(private val dfMobileDataRepository: DFMobileDataRepository): ViewModel()  {

    val askNameLiveData: LiveData<NetworkResult<ResponseBody>?>
        get() = dfMobileDataRepository.askNameLiveData





    fun setAskName(url:String,map: Map<String,String>,context: Context){
        viewModelScope.launch {
            dfMobileDataRepository.setAskNameRepo(url,map,context)
        }
    }




}