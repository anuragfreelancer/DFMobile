package com.dfmobile.ui.home

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.dfmobile.R
import com.dfmobile.databinding.ActivityHomeBinding
import com.dfmobile.ui.setting.ConfigurationAct

class HomeAct : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_home)
        initViews()
    }

    private fun initViews() {

        binding.ivConfig.setOnClickListener {
            startActivity(Intent(this@HomeAct,ConfigurationAct::class.java))
        }
    }
}