package com.dfmobile.repository

import android.content.Context
import androidx.lifecycle.MutableLiveData
import com.dfmobile.R
import com.dfmobile.api.DFMobileDataApi
import com.dfmobile.utils.NetworkResult
import com.dfmobile.utils.NetworkUtils
import okhttp3.ResponseBody
import org.json.JSONException
import org.json.JSONObject
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.inject.Inject

class DFMobileDataRepository @Inject constructor(private val dfMobileDataApi: DFMobileDataApi) {

    private val _serverConnectionLiveData = MutableLiveData<NetworkResult<ResponseBody>?>()
    val serverConnectionLiveData get() = _serverConnectionLiveData

    private val _userLoginLiveData = MutableLiveData<NetworkResult<ResponseBody>?>()
    val userLoginLiveData get() = _userLoginLiveData

    private val _configurationLiveData = MutableLiveData<NetworkResult<ResponseBody>?>()
    val configurationLiveData get() = _configurationLiveData

    private val _logoutLiveData = MutableLiveData<NetworkResult<ResponseBody>?>()
    val logoutLiveData get() = _logoutLiveData


    private val _featuresLiveData = MutableLiveData<NetworkResult<ResponseBody>?>()
    val featuresLiveData get() = _featuresLiveData

    private val _indexFillingLiveData = MutableLiveData<NetworkResult<ResponseBody>?>()
    val indexFillingLiveData get() = _indexFillingLiveData

    private val _askNameLiveData = MutableLiveData<NetworkResult<ResponseBody>?>()
    val askNameLiveData get() = _askNameLiveData


    private val _patternLiveData = MutableLiveData<NetworkResult<ResponseBody>?>()
    val patternLiveData get() = _patternLiveData




    suspend fun serverConnectionRepo(url: String, context: Context) {
        _serverConnectionLiveData.postValue(NetworkResult.Loading())

        try {
            if (NetworkUtils.isNetworkAvailable(context)) {
                val response = dfMobileDataApi.serverConnectionApi(url)

                if (response.isSuccessful && response.body() != null) {
                    // If the response is successful, post the response body
                    _serverConnectionLiveData.postValue(NetworkResult.Success(response.body()!!))
                }
                else {
                    // Handle server-specific error codes (e.g., 503, 504, 500, 404)
                    when (response.code()) {
                        503 -> {
                            _serverConnectionLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                        }
                        504 -> {
                            _serverConnectionLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Gateway Timeout")
                        }
                        500 -> {
                            _serverConnectionLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Internal Server Error")
                        }
                        404 -> {
                            _serverConnectionLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Not Found")
                        }
                        else -> {
                            // Handle other errors (e.g., client-side issues)
                            val errorBody = response.errorBody()!!.charStream().readText()
                            try {
                                val errorObj = JSONObject(errorBody)
                                _serverConnectionLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                            } catch (e: JSONException) {
                                _serverConnectionLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                            }
                        }
                    }
                }

            } else {
                _serverConnectionLiveData.postValue(NetworkResult.Error("Service is unreachable"))
            }

        } catch (e: UnknownHostException) {
            // This exception indicates that the base URL is incorrect or unreachable
            _serverConnectionLiveData.postValue(NetworkResult.Error(context.getString(R.string.invalid_url)))
        } catch (e: ConnectException) {
            // Handle errors related to connection issues, such as wrong URL or server down
            _serverConnectionLiveData.postValue(NetworkResult.Error(context.getString(R.string.unable_to_connect_server)))
        } catch (e: Exception) {
            // Handle any other exceptions (e.g., network issues)
            _serverConnectionLiveData.postValue(NetworkResult.Error("Network error: ${e.message}"))
        }

        catch (e: SocketTimeoutException) {
            // Handle timeout exception (when the request times out)
            _serverConnectionLiveData.postValue(NetworkResult.Error(context.getString(R.string.an_error_has_been_occure)))

        }

    }

    suspend fun userLoginRepo(url:String,map:Map<String,String>,context: Context) {
        _userLoginLiveData.postValue(NetworkResult.Loading())

        try {
            if(NetworkUtils.isNetworkAvailable(context)) {
                val response = dfMobileDataApi.loginApi(url,map)

                if (response.isSuccessful && response.body() != null) {
                    // If the response is successful, post the response body
                    _userLoginLiveData.postValue(NetworkResult.Success(response.body()!!))
                } else if (response.errorBody() != null) {
                    // Check if the error body is JSON or not
                    val errorBody = response.errorBody()!!.charStream().readText()

                    try {
                        // Attempt to parse the error body as JSON
                        val errorObj = JSONObject(errorBody)
                        _userLoginLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                    } catch (e: JSONException) {
                        // If it’s not a valid JSON, handle as plain text
                        _userLoginLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                    }
                } else {
                    // If there’s no error body, post a generic error message
                    _userLoginLiveData.postValue(NetworkResult.Error("Something Went Wrong"))
                }

            }

            else{
                _serverConnectionLiveData.postValue(NetworkResult.Error(context.getString(R.string.network_not_available)))

            }

        }

        catch (e: SocketTimeoutException) {
            // Handle timeout exception (when the request times out)
            _userLoginLiveData.postValue(NetworkResult.Error(context.getString(R.string.an_error_has_been_occure)))

        }


        catch (e: Exception) {
            // Handle any other exceptions (e.g., network issues)
            _userLoginLiveData.postValue(NetworkResult.Error("Network error: ${e.message}"))
        }
    }


/*
    suspend fun userLoginRepo(map: Map<String, String>, context: Context) {
        _userLoginLiveData.postValue(NetworkResult.Loading())

        try {
            if (NetworkUtils.isNetworkAvailable(context)) {
                val response = dfMobileDataApi.loginApi(map)

                if (response.isSuccessful && response.body() != null) {
                    // If the response is successful, post the response body
                    _userLoginLiveData.postValue(NetworkResult.Success(response.body()!!))
                }

                else {
                    // Handle server-specific error codes (e.g., 503, 504, 500, 404)
                    when (response.code()) {
                        503 -> {
                            _userLoginLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                        }
                        504 -> {
                            _userLoginLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                           // showServerUnreachableDialog(context, "Gateway Timeout")
                        }
                        500 -> {
                            _userLoginLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                           // showServerUnreachableDialog(context, "Internal Server Error")
                        }
                        404 -> {
                            _userLoginLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                           // showServerUnreachableDialog(context, "Not Found")
                        }
                        else -> {
                            // Handle other errors (e.g., client-side issues)
                            val errorBody = response.errorBody()!!.charStream().readText()
                            try {
                                val errorObj = JSONObject(errorBody)
                                _userLoginLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                            } catch (e: JSONException) {
                                _userLoginLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                            }
                        }
                    }
                }

            } else {
                // If no network connection, show "Network not available" error
              //  _serverConnectionLiveData.postValue(NetworkResult.Error(context.getString(R.string.network_not_available)))
                _userLoginLiveData.postValue(NetworkResult.Error("Service is unreachable"))
            }

        } catch (e: SocketTimeoutException) {
            // Handle timeout exception (when the request times out)
            _userLoginLiveData.postValue(NetworkResult.Error(context.getString(R.string.an_error_has_been_occure)))
        } catch (e: Exception) {
            // Handle any other exceptions (e.g., network issues)
            _userLoginLiveData.postValue(NetworkResult.Error("Network error: ${e.message}"))
        }
    }
*/

    suspend fun userConfigurationRepo(url:String,userId:String,context: Context) {
        _configurationLiveData.postValue(NetworkResult.Loading())

        try {
            if(NetworkUtils.isNetworkAvailable(context)) {
                val response = dfMobileDataApi.userConfigurationApi(url,userId)

                if (response.isSuccessful && response.body() != null) {
                    // If the response is successful, post the response body
                    _configurationLiveData.postValue(NetworkResult.Success(response.body()!!))
                }

                else {
                    // Handle server-specific error codes (e.g., 503, 504, 500, 404)
                    when (response.code()) {
                        503 -> {
                            _configurationLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                        }
                        504 -> {
                            _configurationLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Gateway Timeout")
                        }
                        500 -> {
                            _configurationLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Internal Server Error")
                        }
                        404 -> {
                            _configurationLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Not Found")
                        }
                        else -> {
                            // Handle other errors (e.g., client-side issues)
                            val errorBody = response.errorBody()!!.charStream().readText()
                            try {
                                val errorObj = JSONObject(errorBody)
                                _configurationLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                            } catch (e: JSONException) {
                                _configurationLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                            }
                        }
                    }
                }

                /*  else if (response.errorBody() != null) {
                    // Check if the error body is JSON or not
                    val errorBody = response.errorBody()!!.charStream().readText()

                    try {
                        // Attempt to parse the error body as JSON
                        val errorObj = JSONObject(errorBody)
                        _configurationLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                    } catch (e: JSONException) {
                        // If it’s not a valid JSON, handle as plain text
                        _configurationLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                    }
                } else {
                    // If there’s no error body, post a generic error message
                    _configurationLiveData.postValue(NetworkResult.Error("Something Went Wrong"))
                }*/

            }

            else{
                //_configurationLiveData.postValue(NetworkResult.Error(context.getString(R.string.network_not_available)))
                _configurationLiveData.postValue(NetworkResult.Error("Service is unreachable"))
            }
        }
        catch (e: SocketTimeoutException) {
            // Handle timeout exception (when the request times out)
            _configurationLiveData.postValue(NetworkResult.Error(context.getString(R.string.an_error_has_been_occure)))

        }

        catch (e: Exception) {
            // Handle any other exceptions (e.g., network issues)
            _configurationLiveData.postValue(NetworkResult.Error("Network error: ${e.message}"))
        }
    }

    suspend fun userLogoutRepo(context: Context) {
        _logoutLiveData.postValue(NetworkResult.Loading())

        try {
            if(NetworkUtils.isNetworkAvailable(context)) {
                val response = dfMobileDataApi.userLogoutApi()

                if (response.isSuccessful && response.body() != null) {
                    // If the response is successful, post the response body
                    _logoutLiveData.postValue(NetworkResult.Success(response.body()!!))
                }


                else if (response.errorBody() != null) {
                    // Check if the error body is JSON or not
                    val errorBody = response.errorBody()!!.charStream().readText()

                    try {
                        // Attempt to parse the error body as JSON
                        val errorObj = JSONObject(errorBody)
                        _logoutLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                    } catch (e: JSONException) {
                        // If it’s not a valid JSON, handle as plain text
                        _logoutLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                    }
                } else {
                    // If there’s no error body, post a generic error message
                    _logoutLiveData.postValue(NetworkResult.Error("Something Went Wrong"))
                }

            }

            else{
                _logoutLiveData.postValue(NetworkResult.Error(context.getString(R.string.network_not_available)))

            }

        }

        catch (e: SocketTimeoutException) {
            // Handle timeout exception (when the request times out)
            _logoutLiveData.postValue(NetworkResult.Error(context.getString(R.string.an_error_has_been_occure)))

        }

        catch (e: Exception) {
            // Handle any other exceptions (e.g., network issues)
            _logoutLiveData.postValue(NetworkResult.Error("Network error: ${e.message}"))
        }



    }

    suspend fun getAllFeaturesRepo(url:String,userId:String,context: Context) {
        _featuresLiveData.postValue(NetworkResult.Loading())

        try {
            if(NetworkUtils.isNetworkAvailable(context)) {
                val response = dfMobileDataApi.userFeaturesApi(url,userId)

                if (response.isSuccessful && response.body() != null) {
                    // If the response is successful, post the response body
                    _featuresLiveData.postValue(NetworkResult.Success(response.body()!!))
                }

                else {
                    // Handle server-specific error codes (e.g., 503, 504, 500, 404)
                    when (response.code()) {
                        503 -> {
                            _featuresLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                        }
                        504 -> {
                            _featuresLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Gateway Timeout")
                        }
                        500 -> {
                            _featuresLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Internal Server Error")
                        }
                        404 -> {
                            _featuresLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Not Found")
                        }
                        else -> {
                            // Handle other errors (e.g., client-side issues)
                            val errorBody = response.errorBody()!!.charStream().readText()
                            try {
                                val errorObj = JSONObject(errorBody)
                                _featuresLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                            } catch (e: JSONException) {
                                _featuresLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                            }
                        }
                    }
                }

                /*  else if (response.errorBody() != null) {
                    // Check if the error body is JSON or not
                    val errorBody = response.errorBody()!!.charStream().readText()

                    try {
                        // Attempt to parse the error body as JSON
                        val errorObj = JSONObject(errorBody)
                        _configurationLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                    } catch (e: JSONException) {
                        // If it’s not a valid JSON, handle as plain text
                        _configurationLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                    }
                } else {
                    // If there’s no error body, post a generic error message
                    _configurationLiveData.postValue(NetworkResult.Error("Something Went Wrong"))
                }*/

            }

            else{
                //_configurationLiveData.postValue(NetworkResult.Error(context.getString(R.string.network_not_available)))
                _featuresLiveData.postValue(NetworkResult.Error("Service is unreachable"))
            }
        }
        catch (e: SocketTimeoutException) {
            // Handle timeout exception (when the request times out)
            _featuresLiveData.postValue(NetworkResult.Error(context.getString(R.string.an_error_has_been_occure)))

        }

        catch (e: Exception) {
            // Handle any other exceptions (e.g., network issues)
            _featuresLiveData.postValue(NetworkResult.Error("Network error: ${e.message}"))
        }
    }

    suspend fun setIndexFillingRepo(url:String,map : Map<String,String>,context: Context) {
        _indexFillingLiveData.postValue(NetworkResult.Loading())

        try {
            if(NetworkUtils.isNetworkAvailable(context)) {
                val response = dfMobileDataApi.indexFillingApi(url,map)

                if (response.isSuccessful && response.body() != null) {
                    // If the response is successful, post the response body
                    _indexFillingLiveData.postValue(NetworkResult.Success(response.body()!!))
                }

                else {
                    // Handle server-specific error codes (e.g., 503, 504, 500, 404)
                    when (response.code()) {
                        503 -> {
                            _indexFillingLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                        }
                        504 -> {
                            _indexFillingLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Gateway Timeout")
                        }
                        500 -> {
                            _indexFillingLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Internal Server Error")
                        }
                        404 -> {
                            _indexFillingLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Not Found")
                        }
                        else -> {
                            // Handle other errors (e.g., client-side issues)
                            val errorBody = response.errorBody()!!.charStream().readText()
                            try {
                                val errorObj = JSONObject(errorBody)
                                _indexFillingLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                            } catch (e: JSONException) {
                                _indexFillingLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                            }
                        }
                    }
                }

                /*  else if (response.errorBody() != null) {
                    // Check if the error body is JSON or not
                    val errorBody = response.errorBody()!!.charStream().readText()

                    try {
                        // Attempt to parse the error body as JSON
                        val errorObj = JSONObject(errorBody)
                        _configurationLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                    } catch (e: JSONException) {
                        // If it’s not a valid JSON, handle as plain text
                        _configurationLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                    }
                } else {
                    // If there’s no error body, post a generic error message
                    _configurationLiveData.postValue(NetworkResult.Error("Something Went Wrong"))
                }*/

            }

            else{
                //_configurationLiveData.postValue(NetworkResult.Error(context.getString(R.string.network_not_available)))
                _indexFillingLiveData.postValue(NetworkResult.Error("Service is unreachable"))
            }
        }
        catch (e: SocketTimeoutException) {
            // Handle timeout exception (when the request times out)
            _indexFillingLiveData.postValue(NetworkResult.Error(context.getString(R.string.an_error_has_been_occure)))

        }

        catch (e: Exception) {
            // Handle any other exceptions (e.g., network issues)
            _indexFillingLiveData.postValue(NetworkResult.Error("Network error: ${e.message}"))
        }
    }

    suspend fun setAskNameRepo(url:String, map: Map<String, String>, context: Context) {
        _askNameLiveData.postValue(NetworkResult.Loading())

        try {
            if(NetworkUtils.isNetworkAvailable(context)) {
                val response = dfMobileDataApi.askNameApi(url,map)

                if (response.isSuccessful && response.body() != null) {
                    // If the response is successful, post the response body
                    _askNameLiveData.postValue(NetworkResult.Success(response.body()!!))
                }

                else {
                    // Handle server-specific error codes (e.g., 503, 504, 500, 404)
                    when (response.code()) {
                        503 -> {
                            _askNameLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                        }
                        504 -> {
                            _askNameLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Gateway Timeout")
                        }
                        500 -> {
                            _askNameLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Internal Server Error")
                        }
                        404 -> {
                            _askNameLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Not Found")
                        }
                        else -> {
                            // Handle other errors (e.g., client-side issues)
                            val errorBody = response.errorBody()!!.charStream().readText()
                            try {
                                val errorObj = JSONObject(errorBody)
                                _askNameLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                            } catch (e: JSONException) {
                                _askNameLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                            }
                        }
                    }
                }

                /*  else if (response.errorBody() != null) {
                    // Check if the error body is JSON or not
                    val errorBody = response.errorBody()!!.charStream().readText()

                    try {
                        // Attempt to parse the error body as JSON
                        val errorObj = JSONObject(errorBody)
                        _configurationLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                    } catch (e: JSONException) {
                        // If it’s not a valid JSON, handle as plain text
                        _configurationLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                    }
                } else {
                    // If there’s no error body, post a generic error message
                    _configurationLiveData.postValue(NetworkResult.Error("Something Went Wrong"))
                }*/

            }

            else{
                //_configurationLiveData.postValue(NetworkResult.Error(context.getString(R.string.network_not_available)))
                _askNameLiveData.postValue(NetworkResult.Error("Service is unreachable"))
            }
        }
        catch (e: SocketTimeoutException) {
            // Handle timeout exception (when the request times out)
            _askNameLiveData.postValue(NetworkResult.Error(context.getString(R.string.an_error_has_been_occure)))

        }

        catch (e: Exception) {
            // Handle any other exceptions (e.g., network issues)
            _askNameLiveData.postValue(NetworkResult.Error("Network error: ${e.message}"))
        }
    }

    suspend fun setRenamingPatternRepo(url:String,map: Map<String, String>,context: Context) {
        _patternLiveData.postValue(NetworkResult.Loading())

        try {
            if(NetworkUtils.isNetworkAvailable(context)) {
                val response = dfMobileDataApi.renamingPatternApi(url,map)

                if (response.isSuccessful && response.body() != null) {
                    // If the response is successful, post the response body
                    _patternLiveData.postValue(NetworkResult.Success(response.body()!!))
                }

                else {
                    // Handle server-specific error codes (e.g., 503, 504, 500, 404)
                    when (response.code()) {
                        503 -> {
                            _patternLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                        }
                        504 -> {
                            _patternLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Gateway Timeout")
                        }
                        500 -> {
                            _patternLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Internal Server Error")
                        }
                        404 -> {
                            _patternLiveData.postValue(NetworkResult.Error("Service is unreachable"))
                            // showServerUnreachableDialog(context, "Not Found")
                        }
                        else -> {
                            // Handle other errors (e.g., client-side issues)
                            val errorBody = response.errorBody()!!.charStream().readText()
                            try {
                                val errorObj = JSONObject(errorBody)
                                _patternLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                            } catch (e: JSONException) {
                                _patternLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                            }
                        }
                    }
                }

                /*  else if (response.errorBody() != null) {
                    // Check if the error body is JSON or not
                    val errorBody = response.errorBody()!!.charStream().readText()

                    try {
                        // Attempt to parse the error body as JSON
                        val errorObj = JSONObject(errorBody)
                        _configurationLiveData.postValue(NetworkResult.Error(errorObj.getString("message")))
                    } catch (e: JSONException) {
                        // If it’s not a valid JSON, handle as plain text
                        _configurationLiveData.postValue(NetworkResult.Error("Error: $errorBody"))
                    }
                } else {
                    // If there’s no error body, post a generic error message
                    _configurationLiveData.postValue(NetworkResult.Error("Something Went Wrong"))
                }*/

            }

            else{
                //_configurationLiveData.postValue(NetworkResult.Error(context.getString(R.string.network_not_available)))
                _patternLiveData.postValue(NetworkResult.Error("Service is unreachable"))
            }
        }
        catch (e: SocketTimeoutException) {
            // Handle timeout exception (when the request times out)
            _patternLiveData.postValue(NetworkResult.Error(context.getString(R.string.an_error_has_been_occure)))

        }

        catch (e: Exception) {
            // Handle any other exceptions (e.g., network issues)
            _patternLiveData.postValue(NetworkResult.Error("Network error: ${e.message}"))
        }
    }



}