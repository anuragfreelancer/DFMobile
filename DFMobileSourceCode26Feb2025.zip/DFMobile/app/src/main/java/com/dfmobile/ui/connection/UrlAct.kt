package com.dfmobile.ui.connection

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.dfmobile.R
import com.dfmobile.databinding.ActivityUrlBinding
import com.dfmobile.ui.home.HomeAct
import com.dfmobile.ui.login.LoginAct
import com.dfmobile.utils.Constants
import com.dfmobile.utils.Helper
import com.dfmobile.utils.NetworkResult
import com.dfmobile.utils.NetworkUtils
import com.dfmobile.utils.PreferenceConnector
import com.dfmobile.utils.SharedPrf
import com.dfmobile.viewmodel.ConnectionViewModel
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject

@AndroidEntryPoint
class UrlAct : AppCompatActivity() ,Helper.Companion.ServiceUnreachableDialogCallback{
    private lateinit var binding : ActivityUrlBinding
    private lateinit var connectionViewModel: ConnectionViewModel

   // private val sharedPrf by lazy { SharedPrf(this) }
    var baseUrl :String=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_url)
        connectionViewModel = ViewModelProvider(this)[ConnectionViewModel::class.java]

        initViews()
    }

    private fun initViews() {

        binding.ivBack.setOnClickListener {
          finish()
        }

        binding.btnConnect.setOnClickListener {
            if(binding.edUrl.text.toString()==""){
                Toast.makeText(this@UrlAct,getString(R.string.please_enter_url),Toast.LENGTH_LONG).show()
            }
            else {
                Log.e("current base url===", binding.edUrl.text.toString())
               baseUrl =  binding.edUrl.text.toString()
                if(!baseUrl.endsWith("/")){
                    baseUrl = "$baseUrl/"
                    //  baseUrl = baseUrl.trimEnd('/')
                } /*else {

                            }*/
                Log.e(" clean base url ===",baseUrl)
                if (NetworkUtils.isNetworkAvailable(this@UrlAct))
                    connectionViewModel.serverConnection(baseUrl+Constants.GET_WS_CONNECTION_API,this@UrlAct)
                 else Toast.makeText(this@UrlAct,getString(R.string.network_not_available),Toast.LENGTH_LONG).show()

            }

        }

        bindObservers()

    }


    private fun bindObservers() {
        connectionViewModel.serverConnectionLiveData.observe(this) {it->
            Helper.hideProgressMessage()
            when (it) {
                is NetworkResult.Success -> {
                    it.data?.let {
                        val jsonObject = JSONObject(it.string())
                        Log.e("server connection Response===",jsonObject.toString())
                        if (jsonObject.getInt("ErrorCode")==0) {
                            binding.tvError.visibility = View.GONE
                            binding.tvUrl.visibility = View.GONE

                          //  sharedPrf.setStoredTag(SharedPrf.DYNAMIC_BASE_URL,baseUrl)
                            PreferenceConnector.setStoredTag(this@UrlAct,
                                PreferenceConnector.DYNAMIC_BASE_URL, baseUrl)
                            startActivity(Intent(this@UrlAct, LoginAct::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                            finish()

                        } else {
                            binding.tvError.visibility = View.VISIBLE
                            binding.edUrl.background = AppCompatResources.getDrawable(this@UrlAct,R.drawable.rounded_red_border10)
                        }

                    }




                }

                is NetworkResult.Error -> {
                    /*if(it.message.toString()=="Service is unreachable"){
                        Helper.serviceUnreachableDialog(this@UrlAct, this@UrlAct)
                    }
                    else {
                        binding.tvError.visibility = View.VISIBLE
                        binding.edUrl.background = AppCompatResources.getDrawable(this@UrlAct,R.drawable.rounded_red_border10)
                        binding.tvError.text =  it.message.toString()
                    }*/

                    if(it.message.toString()=="Service is unreachable"){
                        binding.edUrl.background = AppCompatResources.getDrawable(this@UrlAct,R.drawable.rounded_red_border10)
                        binding.tvError.visibility = View.VISIBLE
                        binding.tvError.text =  getString(R.string.invalid_url)
                    }


                }

                is NetworkResult.Loading -> {
                    Helper.showProgressMessage(this@UrlAct,getString(R.string.please_wait))
                }

                else -> {}
            }
        }



    }

    override fun onRetryClicked(tag:String) {

      //  if(tag=="retry") connectionViewModel.serverConnection(baseUrl+Constants.GET_WS_CONNECTION_API,this@UrlAct)
    }

}