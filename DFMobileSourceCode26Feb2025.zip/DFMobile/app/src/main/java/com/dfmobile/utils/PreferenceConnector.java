package com.dfmobile.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceConnector {

    public static final String PREF_NAME = "DFMobile";
    public static final int MODE = Context.MODE_PRIVATE;

    public static String LOGIN ="login";
    public static String USER_ID ="user_id";
    public static String USER_NAME ="USER_NAME";
    public static String DYNAMIC_BASE_URL ="DYNAMIC_BASE_URL";
    public static String USER_TOKEN ="token";



    public static String setStoredTag(Context context, String key, String value) {
        getEditor(context).putString(key, value).commit();
        return key;
    }

    public static String getStoredTag(Context context, String key, String defValue) {
        return getPreferences(context).getString(key, defValue);
    }


    public static SharedPreferences getPreferences(Context context) {
        return context.getSharedPreferences(PREF_NAME, MODE);
    }

    public static SharedPreferences.Editor getEditor(Context context) {
        return getPreferences(context).edit();
    }


    public static void clearAll(final Context context) {
        getEditor(context).clear().commit();
    }
}
