package com.dfmobile.utils

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.dfmobile.R


class SharedPrf (context: Context) {
    private val USER = "my_preferences"
    private val IS_FIRST_LAUNCH = "is_first_launch"


    private val prefs: SharedPreferences =
        context.getSharedPreferences(USER, Context.MODE_PRIVATE)



    fun getStoredTag(str: String): String {
        return prefs.getString(str, "")!!
    }

    fun setStoredTag(str: String, query: String) {
        prefs.edit().putString(str, query).apply()
       // prefs.edit().putString(str, query).commit()

        val sharedPreferencesListener = SharedPreferences.OnSharedPreferenceChangeListener { sharedPreferences, key ->
            if (key == str) {
                val updatedValue = sharedPreferences.getString(key, null)
                println("Updated Value from Listener: $updatedValue")
            }
        }

        prefs.registerOnSharedPreferenceChangeListener(sharedPreferencesListener)


    }


    fun isFirstLaunch(): Boolean {
        return prefs.getBoolean(IS_FIRST_LAUNCH, true)
    }

    // Set first launch flag to false after the first launch
    fun setFirstLaunchFlag() {
        prefs.edit().putBoolean(IS_FIRST_LAUNCH, false).apply()
    }



    fun clearAll() {
        prefs.edit().clear().apply()
      //  prefs.edit().clear().commit()
    }

    companion object {


    /*    private var INSTANCE: SharedPrf? = null

        // This is the method that returns the singleton instance
        @JvmStatic
        fun getInstance(context: Context): SharedPrf {
            // Using synchronized block for thread-safety
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SharedPrf(context.applicationContext).also { INSTANCE = it }
            }
        }*/



        const val LOGIN: String = "login"
        const val USER_ID: String = "user_id"
        const val USER_NAME: String = "user_name"

        const val DYNAMIC_BASE_URL: String = "base_url"



    }




}
