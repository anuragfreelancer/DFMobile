package com.dfmobile.application

import android.app.Application
import dagger.hilt.android.HiltAndroidApp



@HiltAndroidApp
class DFMobileApp : Application() {
    override fun onCreate() {
        super.onCreate()

    }

}