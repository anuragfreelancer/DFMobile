package com.dfmobile.ui.setting.features

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.dfmobile.R
import com.dfmobile.databinding.ActivityFeaturesBinding
import com.dfmobile.model.FeaturesModel
import com.dfmobile.ui.connection.SplashAct
import com.dfmobile.utils.Constants
import com.dfmobile.utils.Constants.USER_FEATURES_API
import com.dfmobile.utils.Helper
import com.dfmobile.utils.NetworkResult
import com.dfmobile.utils.PreferenceConnector
import com.dfmobile.utils.SharedPrf
import com.dfmobile.viewmodel.FeatureViewModel
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject


@AndroidEntryPoint
class FeaturesAct: AppCompatActivity(),Helper.Companion.ServiceUnreachableDialogCallback {
    private lateinit var binding : ActivityFeaturesBinding
    private lateinit var featureViewModel: FeatureViewModel
    private lateinit var featureAdapter: FeatureAdapter
    private var arrayList : ArrayList<FeaturesModel.Response>?=null
    private var count:Int=0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_features)
        featureViewModel = ViewModelProvider(this)[FeatureViewModel::class.java]

        initViews()
    }

    private fun initViews() {

        arrayList = ArrayList()

        binding.ivBack.setOnClickListener {
            finish()
        }

        featureAdapter = FeatureAdapter(this@FeaturesAct,arrayList)
        binding.rvFeatures.adapter = featureAdapter

        bindObservers()


        featureViewModel.getAllFeatures(
            PreferenceConnector.getStoredTag(this@FeaturesAct,PreferenceConnector.DYNAMIC_BASE_URL,"") + Constants.USER_FEATURES_API ,
            PreferenceConnector.getStoredTag(this@FeaturesAct,PreferenceConnector.USER_ID,""),this@FeaturesAct)

    }


    private fun bindObservers() {
        featureViewModel.featuresLiveData.observe(this) {it->
            Helper.hideProgressMessage()
            when (it) {
                is NetworkResult.Success -> {
                    it.data?.let {
                        val jsonObject = JSONObject(it.string())
                        Log.e("user features Response===",jsonObject.toString())
                        if (jsonObject.getInt("ErrorCode")==0) {

                            val featuresModel: FeaturesModel = Gson().fromJson(
                                jsonObject.toString(),
                                FeaturesModel::class.java
                            )
                            arrayList!!.clear()
                            arrayList!!.addAll(featuresModel.response)

                            for (i in 0 until arrayList!!.size) {
                                if(arrayList!![i].Valor) count += 1
                            }
                            Log.e("count value====",count.toString())

                            binding.tvTitle.text = count.toString() +" " + getString(R.string.functionalities_of) + " " +  arrayList!!.size

                            featureAdapter.notifyDataSetChanged()
                        }

                        else if(jsonObject.getInt("ErrorCode")==-998){
                            Helper.closeSessionDialog(this@FeaturesAct)
                        }


                        else {
                            Toast.makeText(
                                this@FeaturesAct,
                                "" + jsonObject.getString("message"),
                                Toast.LENGTH_SHORT
                            ).show()

                            arrayList!!.clear()
                            featureAdapter.notifyDataSetChanged()
                        }
                    }
                }

                is NetworkResult.Error -> {
                    if(it.message.toString()=="Service is unreachable"){
                        Toast.makeText(
                            this@FeaturesAct,
                            getString(R.string.server_error),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    else {
                        Toast.makeText(
                            this@FeaturesAct,
                            "" + it.message.toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                }

                is NetworkResult.Loading -> {
                    Helper.showProgressMessage(this@FeaturesAct,getString(R.string.please_wait))
                }

                else -> {}
            }
        }




    }

    override fun onRetryClicked(tag:String) {
       // featureViewModel.getAllFeatures(sharedPrf.getStoredTag(SharedPrf.USER_ID),this@FeaturesAct)
    }

}