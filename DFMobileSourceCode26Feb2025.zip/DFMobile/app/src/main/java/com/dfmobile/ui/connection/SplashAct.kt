package com.dfmobile.ui.connection

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.dfmobile.R
import com.dfmobile.databinding.ActivitySplashBinding
import com.dfmobile.ui.home.HomeAct
import com.dfmobile.ui.login.LoginAct
import com.dfmobile.utils.Constants
import com.dfmobile.utils.Helper
import com.dfmobile.utils.Helper.Companion.getDeviceSerial
import com.dfmobile.utils.NetworkResult
import com.dfmobile.utils.PreferenceConnector
import com.dfmobile.utils.SharedPrf
import com.dfmobile.utils.TokenManager
import com.dfmobile.viewmodel.ConnectionViewModel
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject
import javax.inject.Inject

@AndroidEntryPoint
class SplashAct : AppCompatActivity(),Helper.Companion.ServiceUnreachableDialogCallback {
    private lateinit var binding: ActivitySplashBinding
    private val CAMERA_PERMISSION_REQUEST_CODE = 100
    private val CAMERA_PERMISSION_REQUEST_CODE_13 = 200

    private val splashTimeOut: Long = 2000 // 2 seconds
    private var serialNumber: String = ""
    private lateinit var connectionViewModel: ConnectionViewModel
    @Inject
    lateinit var tokenManager: TokenManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or        // Hide status bar
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or   // Hide navigation bar
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY     // Make immersive fullscreen mode
                )
        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash)
        connectionViewModel = ViewModelProvider(this)[ConnectionViewModel::class.java]
        tokenManager = TokenManager(this@SplashAct)

        serialNumber = getDeviceSerial(this@SplashAct)



        PreferenceConnector.setStoredTag(this@SplashAct,PreferenceConnector.LOGIN, "false")
        tokenManager.saveToken(serialNumber)
        Log.e("Device Serial", serialNumber)

        if (Build.VERSION.SDK_INT >= 33) {
            checkAndRequestPermissionsUp13()
        } else {
            checkAndRequestPermissions()

        }


        bindObservers()

    }

    private fun checkAndRequestPermissionsUp13() {
        val cameraPermission =
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
       /* val storageReadPermission =
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)*/


        val permissionsNeeded = mutableListOf<String>()

        // If the camera permission is not granted, add to the list
        if (cameraPermission != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.CAMERA)
        }

        // If the read storage permission is not granted, add to the list
     /*   if (storageReadPermission != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.READ_MEDIA_VIDEO)
        }*/

        // If the write storage permission is not granted, add to the list


        // If we have permissions that are not granted, request them
        if (permissionsNeeded.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsNeeded.toTypedArray(),
                CAMERA_PERMISSION_REQUEST_CODE_13
            )
        }
        else {
            // Permissions already granted, proceed to the next activity
            proceedToNextActivity()

        }
    }

    private fun checkAndRequestPermissions() {
        val cameraPermission =
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
      /*  val storageReadPermission =
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
        val storageWritePermission =
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)*/

        val permissionsNeeded = mutableListOf<String>()

        // If the camera permission is not granted, add to the list
        if (cameraPermission != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.CAMERA)
        }

        // If the read storage permission is not granted, add to the list
      /*  if (storageReadPermission != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        // If the write storage permission is not granted, add to the list
        if (storageWritePermission != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }*/

        // If we have permissions that are not granted, request them
        if (permissionsNeeded.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsNeeded.toTypedArray(),
                CAMERA_PERMISSION_REQUEST_CODE
            )

        } else {
            // Permissions already granted, proceed to the next activity
            proceedToNextActivity()
        }
    }


    // Handle the result of the permission request
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        // If all permissions are granted
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            var allPermissionsGranted = true
            for (result in grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false
                    break
                }
            }

            if (allPermissionsGranted) {
                // Permissions granted, proceed to the next activity
                proceedToNextActivity()
            } else {
                // Permissions not granted, show a message to the user
                Toast.makeText(
                    this,
                    "Permissions are required to use this app.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        } else {
            var allPermissionsGranted = true
            for (result in grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false
                    break
                }
            }

            if (allPermissionsGranted) {
                // Permissions granted, proceed to the next activity
                proceedToNextActivity()
            } else {
                // Permissions not granted, show a message to the user
                Toast.makeText(
                    this,
                    "Permissions are required to use this app.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // Proceed to the next activity after permission check
    private fun proceedToNextActivity() {
        Handler(Looper.getMainLooper()).postDelayed({
            if (PreferenceConnector.getStoredTag(this@SplashAct,PreferenceConnector.LOGIN, "").equals("true")) {
                startActivity(Intent(this, HomeAct::class.java))
                finish()
            } else {
                if (  PreferenceConnector.getStoredTag(this@SplashAct,PreferenceConnector.DYNAMIC_BASE_URL, "").equals("")
                    || PreferenceConnector.getStoredTag(this@SplashAct,PreferenceConnector.DYNAMIC_BASE_URL, "").equals("https://local.df-server.info:24003/")) {
                    startActivity(Intent(this, SelectServerTypeAct::class.java))
                    finish()
                } else {
                    connectionViewModel.serverConnection( PreferenceConnector.getStoredTag(this@SplashAct,PreferenceConnector.DYNAMIC_BASE_URL, "") + Constants.GET_WS_CONNECTION_API,this@SplashAct)

                }
            }

        }, splashTimeOut)
    }



    private fun bindObservers() {
        connectionViewModel.serverConnectionLiveData.observe(this) { it ->
            Helper.hideProgressMessage()
            when (it) {
                is NetworkResult.Success -> {
                    it.data?.let {
                        val jsonObject = JSONObject(it.string())
                        Log.e("server connection Response===", jsonObject.toString())
                        if (jsonObject.getInt("ErrorCode") == 0) {
                            startActivity(Intent(this, LoginAct::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                            finish()
                        } else {
                            // binding.tvError.visibility = View.VISIBLE

                        }

                    }


                }

                is NetworkResult.Error -> {
                    Log.e("error=====", it.message.toString())
                    if(it.message.toString()=="Service is unreachable"){
                         Helper.serviceUnreachableDialog(this@SplashAct, this@SplashAct)

                    }

                }

                is NetworkResult.Loading -> {
                    Helper.showProgressMessage(
                        this@SplashAct,
                        getString(R.string.please_wait)
                    )
                }

                else -> {}
            }
        }


    }


    override fun onRetryClicked(tag:String) {
       if(tag=="retry")
        connectionViewModel.serverConnection( PreferenceConnector.getStoredTag(this@SplashAct,PreferenceConnector.DYNAMIC_BASE_URL, "") + Constants.GET_WS_CONNECTION_API,this@SplashAct)
       else {
           PreferenceConnector.setStoredTag(this@SplashAct,PreferenceConnector.DYNAMIC_BASE_URL, "")
           startActivity(Intent(this, SelectServerTypeAct::class.java)
               .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
           finish()
       }
    }


}